# OpenWhoop

Local-first Flutter app: recovery, strain and sleep dashboard, 3-month fitness-age
estimate, and an AI coach. All data stays on the device (Drift/SQLite).
Independent project, not affiliated with or endorsed by WHOOP.

## Option A: get a downloadable APK without installing anything (recommended)

1. Create a GitHub repository and push this folder to its `main` branch.
2. Open the **Actions** tab and wait for **Build APK** to finish (about 5-8 minutes).
3. Your download link is
   `https://github.com/<you>/<repo>/releases/latest/download/openwhoop.apk`
   Open it on your phone to install.
4. Optional store-style page: Settings > Pages > deploy from branch, folder `/docs`.
   `docs/index.html` shows a Download button that points at the latest release.

### Updates that install over the old version
Without a signing key, every build gets a different debug signature and Android
refuses to update in place. Do this once:
```bash
./scripts/make_keystore.sh
```
Add the four secrets it prints (KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS,
KEY_PASSWORD) under Settings > Secrets and variables > Actions. Back up `release.jks`.
Version codes increase automatically with each run.

## Option B: build locally

Prerequisites: Flutter stable, Android SDK (`flutter doctor` green), JDK 17, perl.
```bash
./scripts/setup.sh                 # creates android/, patches it, pub get, build_runner
flutter build apk --release        # build/app/outputs/flutter-apk/app-release.apk
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

## Using it
1. Settings: set birth year (needed for fitness age) and import your export zip.
2. Settings: pick an AI provider. Local = any Ollama-compatible HTTP endpoint
   (Ollama in Termux on the phone, or on your LAN). Cloud keys go to Keystore-backed storage.
3. If a build fails after a Flutter upgrade, run `flutter pub upgrade` and rebuild.
