import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../providers/providers.dart';
import '../theme.dart';
import '../widgets/cards.dart';
import '../widgets/dashboard_cards.dart';
import 'ai_coach_screen.dart';
import 'recovery_screen.dart';
import 'settings_screen.dart';
import 'strain_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      OverviewTab(onOpenSettings: () => setState(() => _index = 4)),
      const StrainScreen(),
      const RecoveryScreen(),
      const AiCoachScreen(),
      const SettingsScreen(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.donut_large_outlined), selectedIcon: Icon(Icons.donut_large), label: 'Today'),
          NavigationDestination(icon: Icon(Icons.local_fire_department_outlined), selectedIcon: Icon(Icons.local_fire_department), label: 'Strain'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Recovery'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'AI Coach'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class OverviewTab extends ConsumerWidget {
  const OverviewTab({super.key, required this.onOpenSettings});
  final VoidCallback onOpenSettings;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dash = ref.watch(dashboardProvider);
    final age = ref.watch(whoopAgeProvider);
    return dash.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => EmptyState(message: 'Could not load data: $e'),
      data: (d) {
        final cycle = d.cycle;
        if (cycle == null) {
          return EmptyState(
            message: 'No data yet. Import your WHOOP data export (zip, CSV or JSON) to get started.',
            actionLabel: 'Open settings',
            onAction: onOpenSettings,
          );
        }
        return RefreshIndicator(
          onRefresh: () async => ref.read(refreshProvider.notifier).state++,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 14, left: 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('OVERVIEW', style: AppText.label),
                    const SizedBox(height: 2),
                    Text(DateFormat('EEEE, d MMMM').format(cycle.start), style: AppText.medium),
                  ],
                ),
              ),
              SummaryRings(cycle: cycle, sleep: d.sleep),
              StrainCard(cycle: cycle),
              if (d.recoveryDate != null)
                Padding(
                  padding: const EdgeInsets.fromLTRB(6, 0, 6, 8),
                  child: Text(
                    'Today is not scored yet. Showing recovery from ${DateFormat('EEE d MMM').format(d.recoveryDate!)}.',
                    style: AppText.tiny,
                  ),
                ),
              RecoveryCard(cycle: cycle),
              if (d.sleep != null) SleepCard(sleep: d.sleep!),
              StressCard(cycle: cycle, trends: d.trends),
              if (d.week.days >= 3) WeeklyCard(week: d.week, baseline: d.trends),
              AgeCard(result: age.valueOrNull, onSetup: onOpenSettings),
            ],
          ),
        );
      },
    );
  }
}
