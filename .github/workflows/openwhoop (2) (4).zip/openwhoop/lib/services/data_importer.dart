import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:csv/csv.dart';
import 'package:drift/drift.dart' show Value;

import '../database/database.dart';

class ImportReport {
  int cycles = 0;
  int sleeps = 0;
  int workouts = 0;
  final List<String> notes = [];
  int get total => cycles + sleeps + workouts;
  @override
  String toString() =>
      'Imported $cycles cycles, $sleeps sleeps, $workouts workouts.${notes.isEmpty ? '' : '\n${notes.join('\n')}'}';
}

String _norm(String k) => k.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

class _Row {
  _Row(this.m);
  final Map<String, dynamic> m;

  String? s(List<String> keys) {
    for (final k in keys) {
      final v = m[k];
      if (v != null && v.toString().trim().isNotEmpty) return v.toString().trim();
    }
    return null;
  }

  double? d(List<String> keys) {
    final v = s(keys);
    return v == null ? null : double.tryParse(v.replaceAll(',', ''));
  }

  DateTime? t(List<String> keys) {
    final v = s(keys);
    return v == null ? null : DateTime.tryParse(v);
  }

  bool b(List<String> keys) {
    final v = s(keys)?.toLowerCase();
    return v == 'true' || v == '1' || v == 'yes';
  }

  bool has(String key) => m.containsKey(key);
}

class _Batch {
  final cycles = <CyclesCompanion>[];
  final sleeps = <SleepsCompanion>[];
  final workouts = <WorkoutsCompanion>[];
}

/// Parses the WHOOP data-export package (zip, or loose CSV/JSON files):
/// physiological_cycles.csv, sleeps.csv, workouts.csv (+ JSON equivalents).
/// Timestamps are treated as local wall-clock time, as exported.
class DataImporter {
  DataImporter(this._db);
  final AppDatabase _db;

  Future<ImportReport> importFiles(Map<String, Uint8List> files) async {
    final report = ImportReport();
    final batch = _Batch();
    for (final e in files.entries) {
      try {
        _ingest(e.key, e.value, batch, report);
      } catch (err) {
        report.notes.add('Skipped ${e.key}: $err');
      }
    }
    await _db.upsertCycles(batch.cycles);
    await _db.upsertSleeps(batch.sleeps);
    await _db.upsertWorkouts(batch.workouts);
    report.cycles = batch.cycles.length;
    report.sleeps = batch.sleeps.length;
    report.workouts = batch.workouts.length;
    if (report.total == 0) {
      report.notes.add('No recognisable rows found. Expected physiological_cycles, sleeps or workouts files.');
    }
    return report;
  }

  void _ingest(String name, Uint8List bytes, _Batch b, ImportReport r) {
    final lower = name.toLowerCase();
    if (lower.endsWith('.zip')) {
      final archive = ZipDecoder().decodeBytes(bytes);
      for (final f in archive) {
        if (f.isFile) {
          _ingest(f.name, Uint8List.fromList(f.content as List<int>), b, r);
        }
      }
    } else if (lower.endsWith('.csv')) {
      _route(name, _parseCsv(utf8.decode(bytes, allowMalformed: true)), b, r);
    } else if (lower.endsWith('.json')) {
      final decoded = jsonDecode(utf8.decode(bytes, allowMalformed: true));
      if (decoded is List) {
        _route(name, _jsonRows(decoded), b, r);
      } else if (decoded is Map) {
        decoded.forEach((k, v) {
          if (v is List) _route('$name/$k', _jsonRows(v), b, r);
        });
      }
    }
  }

  List<_Row> _parseCsv(String text) {
    final clean = text.replaceFirst('\uFEFF', '').replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    final rows = CsvToListConverter(eol: '\n', shouldParseNumbers: false).convert(clean);
    if (rows.length < 2) return [];
    final headers = rows.first.map((h) => _norm(h.toString())).toList();
    final out = <_Row>[];
    for (final row in rows.skip(1)) {
      if (row.isEmpty || row.every((c) => c.toString().trim().isEmpty)) continue;
      final map = <String, dynamic>{};
      for (var i = 0; i < headers.length && i < row.length; i++) {
        map[headers[i]] = row[i];
      }
      out.add(_Row(map));
    }
    return out;
  }

  List<_Row> _jsonRows(List<dynamic> list) {
    final rows = <_Row>[];
    for (final item in list) {
      if (item is! Map) continue;
      final out = <String, dynamic>{};
      void walk(String path, String leaf, dynamic v) {
        if (v is Map) {
          v.forEach((k, val) {
            final n = _norm('$k');
            walk('$path$n', n, val);
          });
        } else if (v != null && v is! List) {
          out.putIfAbsent(path, () => v);
          out.putIfAbsent(leaf, () => v);
        }
      }

      item.forEach((k, v) {
        final n = _norm('$k');
        walk(n, n, v);
      });
      rows.add(_Row(out));
    }
    return rows;
  }

  String? _kind(String name, List<_Row> rows) {
    if (rows.isNotEmpty) {
      final r = rows.first;
      if (r.has('recoveryscore') || r.has('daystrain')) return 'cycles';
      if (r.has('workoutstarttime') || r.has('activityname')) return 'workouts';
      if (r.has('sleeponset')) return 'sleeps';
    }
    final n = name.toLowerCase();
    if (n.contains('physiological') || n.contains('cycle')) return 'cycles';
    if (n.contains('workout')) return 'workouts';
    if (n.contains('sleep')) return 'sleeps';
    return null;
  }

  void _route(String name, List<_Row> rows, _Batch b, ImportReport r) {
    if (rows.isEmpty) return;
    switch (_kind(name, rows)) {
      case 'cycles':
        for (final row in rows) {
          final c = _cycle(row);
          if (c != null) b.cycles.add(c);
          // The physiological-cycles export also carries that night's sleep columns.
          final s = _sleep(row);
          if (s != null) b.sleeps.add(s);
        }
      case 'sleeps':
        for (final row in rows) {
          final s = _sleep(row);
          if (s != null) b.sleeps.add(s);
        }
      case 'workouts':
        for (final row in rows) {
          final w = _workout(row);
          if (w != null) b.workouts.add(w);
        }
      default:
        r.notes.add('Ignored $name (not a cycles, sleep or workout file).');
    }
  }

  CyclesCompanion? _cycle(_Row r) {
    final start = r.t(['cyclestarttime', 'start']);
    if (start == null) return null;
    return CyclesCompanion(
      start: Value(start),
      end: Value(r.t(['cycleendtime', 'end'])),
      recoveryScore: Value(r.d(['recoveryscore', 'recoveryscorepercentage'])),
      restingHr: Value(r.d(['restingheartratebpm', 'restingheartrate'])),
      hrv: Value(r.d(['heartratevariabilityms', 'hrvrmssdmilli', 'hrv'])),
      skinTemp: Value(r.d(['skintempcelsius', 'skintemp'])),
      spo2: Value(r.d(['bloodoxygen', 'spo2percentage', 'spo2'])),
      dayStrain: Value(r.d(['daystrain', 'strain'])),
      energyKcal: Value(r.d(['energyburnedcal', 'energyburnedkcal'])),
      maxHr: Value(r.d(['maxhrbpm', 'maxheartrate'])),
      avgHr: Value(r.d(['averagehrbpm', 'averageheartrate'])),
    );
  }

  SleepsCompanion? _sleep(_Row r) {
    final onset = r.t(['sleeponset', 'start']);
    if (onset == null) return null;
    return SleepsCompanion(
      onset: Value(onset),
      wake: Value(r.t(['wakeonset', 'wake', 'end'])),
      performance: Value(r.d(['sleepperformance', 'sleepperformancepercentage'])),
      respRate: Value(r.d(['respiratoryraterpm', 'respiratoryrate'])),
      asleepMin: Value(r.d(['asleepdurationmin'])),
      inBedMin: Value(r.d(['inbeddurationmin'])),
      lightMin: Value(r.d(['lightsleepdurationmin'])),
      deepMin: Value(r.d(['deepswsdurationmin', 'deepdurationmin'])),
      remMin: Value(r.d(['remdurationmin'])),
      awakeMin: Value(r.d(['awakedurationmin'])),
      needMin: Value(r.d(['sleepneedmin'])),
      debtMin: Value(r.d(['sleepdebtmin'])),
      efficiency: Value(r.d(['sleepefficiency', 'sleepefficiencypercentage'])),
      consistency: Value(r.d(['sleepconsistency', 'sleepconsistencypercentage'])),
      isNap: Value(r.b(['nap'])),
    );
  }

  WorkoutsCompanion? _workout(_Row r) {
    final start = r.t(['workoutstarttime', 'start']);
    if (start == null) return null;
    final end = r.t(['workoutendtime', 'end']);
    final duration = r.d(['durationmin']) ?? (end == null ? null : end.difference(start).inSeconds / 60.0);
    return WorkoutsCompanion(
      start: Value(start),
      end: Value(end),
      durationMin: Value(duration),
      activity: Value(r.s(['activityname', 'sportname']) ?? 'Activity'),
      strain: Value(r.d(['activitystrain', 'strain'])),
      energyKcal: Value(r.d(['energyburnedcal', 'energyburnedkcal'])),
      maxHr: Value(r.d(['maxhrbpm', 'maxheartrate'])),
      avgHr: Value(r.d(['averagehrbpm', 'averageheartrate'])),
      zone1: Value(r.d(['hrzone1'])),
      zone2: Value(r.d(['hrzone2'])),
      zone3: Value(r.d(['hrzone3'])),
      zone4: Value(r.d(['hrzone4'])),
      zone5: Value(r.d(['hrzone5'])),
      distanceM: Value(r.d(['distancemeters', 'distancemeter'])),
      altitudeGainM: Value(r.d(['altitudegainmeters', 'altitudegainmeter'])),
      hasGps: Value(r.b(['gpsenabled'])),
    );
  }
}
