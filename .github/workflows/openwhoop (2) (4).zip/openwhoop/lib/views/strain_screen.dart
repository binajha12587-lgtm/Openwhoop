import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../database/database.dart';
import '../providers/providers.dart';
import '../theme.dart';
import '../widgets/cards.dart';

const _zoneColors = [
  Color(0xFF5AC8FA),
  Color(0xFF34C759),
  Color(0xFFFFD60A),
  Color(0xFFFF9500),
  Color(0xFFFF3B30),
];

class StrainScreen extends ConsumerWidget {
  const StrainScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final workouts = ref.watch(workoutsProvider);
    final cycles = ref.watch(trendCyclesProvider(30));
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 14),
          child: Text('STRAIN & WORKOUTS', style: AppText.label),
        ),
        cycles.when(
          data: (c) => _DailyStrainChart(cycles: c),
          loading: () => const SizedBox(height: 120, child: Center(child: CircularProgressIndicator())),
          error: (e, _) => Text('$e'),
        ),
        workouts.when(
          loading: () => const SizedBox.shrink(),
          error: (e, _) => Text('$e'),
          data: (list) {
            if (list.isEmpty) {
              return const AppCard(child: Text('No workouts logged in the last 60 days.', style: AppText.dim));
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _ZoneSummary(workouts: list),
                for (final w in list) _WorkoutTile(workout: w),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _DailyStrainChart extends StatelessWidget {
  const _DailyStrainChart({required this.cycles});
  final List<Cycle> cycles;

  @override
  Widget build(BuildContext context) {
    final withStrain = cycles.where((c) => c.dayStrain != null).toList();
    if (withStrain.isEmpty) {
      return const AppCard(title: 'Daily strain · 30 days', child: Text('No strain data yet.', style: AppText.dim));
    }
    final avg = withStrain.fold<double>(0, (a, c) => a + c.dayStrain!) / withStrain.length;
    return AppCard(
      title: 'Daily strain · 30 days',
      trailing: Text('AVG ${avg.toStringAsFixed(1)}', style: AppText.label.copyWith(color: AppColors.strain)),
      child: SizedBox(
        height: 150,
        child: BarChart(
          BarChartData(
            maxY: 21,
            minY: 0,
            gridData: const FlGridData(show: false),
            borderData: FlBorderData(show: false),
            titlesData: FlTitlesData(
              topTitles: const AxisTitles(),
              rightTitles: const AxisTitles(),
              bottomTitles: const AxisTitles(),
              leftTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 28,
                  interval: 7,
                  getTitlesWidget: (v, meta) =>
                      SideTitleWidget(meta: meta, child: Text(v.toInt().toString(), style: AppText.tiny)),
                ),
              ),
            ),
            barGroups: [
              for (var i = 0; i < withStrain.length; i++)
                BarChartGroupData(x: i, barRods: [
                  BarChartRodData(
                    toY: withStrain[i].dayStrain!,
                    color: AppColors.strain,
                    width: 6,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ]),
            ],
          ),
        ),
      ),
    );
  }
}

class _ZoneSummary extends StatelessWidget {
  const _ZoneSummary({required this.workouts});
  final List<Workout> workouts;

  @override
  Widget build(BuildContext context) {
    final minutes = List<double>.filled(5, 0);
    for (final w in workouts) {
      final dur = w.durationMin ?? 0;
      final z = [w.zone1, w.zone2, w.zone3, w.zone4, w.zone5];
      for (var i = 0; i < 5; i++) {
        minutes[i] += (z[i] ?? 0) / 100 * dur;
      }
    }
    final total = minutes.fold<double>(0, (a, b) => a + b);
    return AppCard(
      title: 'Heart rate zones · 60 days',
      child: total <= 0
          ? const Text('No zone data in your workouts.', style: AppText.dim)
          : Column(children: [
              for (var i = 4; i >= 0; i--) _zoneRow('Zone ${i + 1}', minutes[i], total, _zoneColors[i]),
            ]),
    );
  }
}

Widget _zoneRow(String label, double minutes, double total, Color color) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        SizedBox(width: 56, child: Text(label, style: AppText.dim)),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: LinearProgressIndicator(
              value: total <= 0 ? 0 : minutes / total,
              minHeight: 10,
              color: color,
              backgroundColor: AppColors.track,
            ),
          ),
        ),
        SizedBox(width: 64, child: Text(fmtMinutes(minutes), textAlign: TextAlign.right, style: AppText.body)),
      ]),
    );

class _WorkoutTile extends StatelessWidget {
  const _WorkoutTile({required this.workout});
  final Workout workout;

  @override
  Widget build(BuildContext context) {
    final w = workout;
    final dur = w.durationMin ?? 0;
    final zones = [w.zone1, w.zone2, w.zone3, w.zone4, w.zone5];
    final kcal = w.energyKcal;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(20)),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
          childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 16),
          title: Text(w.activity, style: AppText.body.copyWith(fontWeight: FontWeight.w700)),
          subtitle: Text(
            '${DateFormat('EEE d MMM, HH:mm').format(w.start)} · ${fmtMinutes(dur)}'
            '${w.hasGps ? ' · GPS' : ''}',
            style: AppText.dim,
          ),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(fmtNum(w.strain, dp: 1), style: AppText.medium.copyWith(color: AppColors.strain)),
              const Text('STRAIN', style: AppText.tiny),
            ],
          ),
          children: [
            Row(children: [
              Expanded(child: StatTile(label: 'Energy', value: kcal == null ? '--' : '${(kcal * 4.184).round()}', unit: 'kJ')),
              Expanded(child: StatTile(label: 'Avg HR', value: fmtNum(w.avgHr), unit: 'bpm')),
              Expanded(child: StatTile(label: 'Max HR', value: fmtNum(w.maxHr), unit: 'bpm')),
            ]),
            if (w.hasGps && (w.distanceM ?? 0) > 0) ...[
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: StatTile(label: 'Distance', value: ((w.distanceM ?? 0) / 1000).toStringAsFixed(2), unit: 'km')),
                Expanded(child: StatTile(label: 'Elev. gain', value: fmtNum(w.altitudeGainM), unit: 'm')),
                const Expanded(child: SizedBox.shrink()),
              ]),
            ],
            const SizedBox(height: 14),
            for (var i = 4; i >= 0; i--)
              _zoneRow('Zone ${i + 1}', (zones[i] ?? 0) / 100 * dur, dur <= 0 ? 1 : dur, _zoneColors[i]),
          ],
        ),
      ),
    );
  }
}
