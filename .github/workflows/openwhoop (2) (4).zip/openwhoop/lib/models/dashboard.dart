import '../database/database.dart';

double? avgOf(Iterable<double?> values) {
  var sum = 0.0;
  var n = 0;
  for (final v in values) {
    if (v != null) {
      sum += v;
      n++;
    }
  }
  return n == 0 ? null : sum / n;
}

/// Suggested daily strain window given the morning recovery score.
({double lo, double hi}) strainTargetFor(double? recovery) {
  if (recovery == null) return (lo: 8.0, hi: 14.0);
  if (recovery >= 67) return (lo: 12.0, hi: 18.0);
  if (recovery >= 34) return (lo: 8.0, hi: 14.0);
  return (lo: 0.0, hi: 10.0);
}

class UserProfile {
  const UserProfile({this.birthYear, this.sex});
  final int? birthYear;
  final String? sex;

  double? ageAt(DateTime when) => birthYear == null ? null : (when.year - birthYear!) + 0.5;
}

class TrendSummary {
  const TrendSummary({
    required this.days,
    this.recovery,
    this.hrv,
    this.rhr,
    this.strain,
    this.spo2,
    this.sleepPerformance,
    this.sleepDebtMin,
    this.respRate,
  });

  final int days;
  final double? recovery, hrv, rhr, strain, spo2, sleepPerformance, sleepDebtMin, respRate;

  factory TrendSummary.from(List<Cycle> cycles, List<Sleep> sleeps) => TrendSummary(
        days: cycles.length,
        recovery: avgOf(cycles.map((c) => c.recoveryScore)),
        hrv: avgOf(cycles.map((c) => c.hrv)),
        rhr: avgOf(cycles.map((c) => c.restingHr)),
        strain: avgOf(cycles.map((c) => c.dayStrain)),
        spo2: avgOf(cycles.map((c) => c.spo2)),
        sleepPerformance: avgOf(sleeps.map((s) => s.performance)),
        sleepDebtMin: avgOf(sleeps.map((s) => s.debtMin)),
        respRate: avgOf(sleeps.map((s) => s.respRate)),
      );
}

class Dashboard {
  const Dashboard({
    required this.cycle,
    required this.sleep,
    required this.trends,
    required this.week,
    this.recoveryDate,
  });
  final Cycle? cycle;
  final Sleep? sleep;

  /// 90-day baseline.
  final TrendSummary trends;

  /// Last 7 days.
  final TrendSummary week;

  /// Set when today's cycle has no recovery yet and an earlier score is shown instead.
  final DateTime? recoveryDate;
}
