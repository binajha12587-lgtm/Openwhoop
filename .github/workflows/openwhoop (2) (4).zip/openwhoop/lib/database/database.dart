import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

part 'database.g.dart';

@DataClassName('Cycle')
class Cycles extends Table {
  DateTimeColumn get start => dateTime()();
  DateTimeColumn get end => dateTime().nullable()();
  RealColumn get recoveryScore => real().nullable()();
  RealColumn get restingHr => real().nullable()();
  RealColumn get hrv => real().nullable()();
  RealColumn get skinTemp => real().nullable()();
  RealColumn get spo2 => real().nullable()();
  RealColumn get dayStrain => real().nullable()();
  RealColumn get energyKcal => real().nullable()();
  RealColumn get maxHr => real().nullable()();
  RealColumn get avgHr => real().nullable()();

  @override
  Set<Column> get primaryKey => {start};
}

@DataClassName('Sleep')
class Sleeps extends Table {
  DateTimeColumn get onset => dateTime()();
  DateTimeColumn get wake => dateTime().nullable()();
  RealColumn get performance => real().nullable()();
  RealColumn get respRate => real().nullable()();
  RealColumn get asleepMin => real().nullable()();
  RealColumn get inBedMin => real().nullable()();
  RealColumn get lightMin => real().nullable()();
  RealColumn get deepMin => real().nullable()();
  RealColumn get remMin => real().nullable()();
  RealColumn get awakeMin => real().nullable()();
  RealColumn get needMin => real().nullable()();
  RealColumn get debtMin => real().nullable()();
  RealColumn get efficiency => real().nullable()();
  RealColumn get consistency => real().nullable()();
  BoolColumn get isNap => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {onset};
}

@DataClassName('Workout')
class Workouts extends Table {
  DateTimeColumn get start => dateTime()();
  DateTimeColumn get end => dateTime().nullable()();
  RealColumn get durationMin => real().nullable()();
  TextColumn get activity => text().withDefault(const Constant('Activity'))();
  RealColumn get strain => real().nullable()();
  RealColumn get energyKcal => real().nullable()();
  RealColumn get maxHr => real().nullable()();
  RealColumn get avgHr => real().nullable()();
  RealColumn get zone1 => real().nullable()();
  RealColumn get zone2 => real().nullable()();
  RealColumn get zone3 => real().nullable()();
  RealColumn get zone4 => real().nullable()();
  RealColumn get zone5 => real().nullable()();
  RealColumn get distanceM => real().nullable()();
  RealColumn get altitudeGainM => real().nullable()();
  BoolColumn get hasGps => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {start};
}

/// Simple key/value store for profile data (birth year, sex, ...).
@DataClassName('UserMetric')
class UserMetrics extends Table {
  TextColumn get metricKey => text()();
  TextColumn get metricValue => text()();

  @override
  Set<Column> get primaryKey => {metricKey};
}

class DataStats {
  const DataStats({
    required this.cycles,
    required this.sleeps,
    required this.workouts,
    this.first,
    this.last,
  });
  final int cycles, sleeps, workouts;
  final DateTime? first, last;
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'openwhoop.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}

@DriftDatabase(tables: [Cycles, Sleeps, Workouts, UserMetrics])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());
  AppDatabase.forTesting(super.e);

  @override
  int get schemaVersion => 1;

  // ---- Cycles -----------------------------------------------------------
  Future<List<Cycle>> cyclesBetween(DateTime from, DateTime to) =>
      (select(cycles)
            ..where((t) => t.start.isBiggerOrEqualValue(from) & t.start.isSmallerOrEqualValue(to))
            ..orderBy([(t) => OrderingTerm.asc(t.start)]))
          .get();

  Future<Cycle?> latestCycle() => (select(cycles)
        ..orderBy([(t) => OrderingTerm.desc(t.start)])
        ..limit(1))
      .getSingleOrNull();

  Future<Cycle?> latestRecoveredCycle() => (select(cycles)
        ..where((t) => t.recoveryScore.isNotNull())
        ..orderBy([(t) => OrderingTerm.desc(t.start)])
        ..limit(1))
      .getSingleOrNull();

  Future<DataStats> stats() async {
    final cCount = cycles.start.count();
    final cMin = cycles.start.min();
    final cMax = cycles.start.max();
    final c = await (selectOnly(cycles)..addColumns([cCount, cMin, cMax])).getSingle();
    final sCount = sleeps.onset.count();
    final s = await (selectOnly(sleeps)..addColumns([sCount])).getSingle();
    final wCount = workouts.start.count();
    final w = await (selectOnly(workouts)..addColumns([wCount])).getSingle();
    return DataStats(
      cycles: c.read(cCount) ?? 0,
      sleeps: s.read(sCount) ?? 0,
      workouts: w.read(wCount) ?? 0,
      first: c.read(cMin),
      last: c.read(cMax),
    );
  }

  Future<void> upsertCycles(List<CyclesCompanion> rows) =>
      batch((b) => b.insertAllOnConflictUpdate(cycles, rows));

  // ---- Sleeps -----------------------------------------------------------
  Future<List<Sleep>> sleepsBetween(DateTime from, DateTime to) =>
      (select(sleeps)
            ..where((t) =>
                t.onset.isBiggerOrEqualValue(from) &
                t.onset.isSmallerOrEqualValue(to) &
                t.isNap.equals(false))
            ..orderBy([(t) => OrderingTerm.asc(t.onset)]))
          .get();

  Future<Sleep?> latestSleep() => (select(sleeps)
        ..where((t) => t.isNap.equals(false))
        ..orderBy([(t) => OrderingTerm.desc(t.onset)])
        ..limit(1))
      .getSingleOrNull();

  Future<void> upsertSleeps(List<SleepsCompanion> rows) =>
      batch((b) => b.insertAllOnConflictUpdate(sleeps, rows));

  // ---- Workouts ---------------------------------------------------------
  Future<List<Workout>> workoutsBetween(DateTime from, DateTime to) =>
      (select(workouts)
            ..where((t) => t.start.isBiggerOrEqualValue(from) & t.start.isSmallerOrEqualValue(to))
            ..orderBy([(t) => OrderingTerm.desc(t.start)]))
          .get();

  Future<void> upsertWorkouts(List<WorkoutsCompanion> rows) =>
      batch((b) => b.insertAllOnConflictUpdate(workouts, rows));

  // ---- Profile ----------------------------------------------------------
  Future<String?> getMetric(String key) async {
    final row = await (select(userMetrics)..where((t) => t.metricKey.equals(key))).getSingleOrNull();
    return row?.metricValue;
  }

  Future<void> setMetric(String key, String value) => into(userMetrics)
      .insertOnConflictUpdate(UserMetricsCompanion.insert(metricKey: key, metricValue: value));

  // ---- Maintenance ------------------------------------------------------
  Future<void> clearActivityData() async {
    await delete(cycles).go();
    await delete(sleeps).go();
    await delete(workouts).go();
  }
}
