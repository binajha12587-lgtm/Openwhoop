import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../theme.dart';
import 'cards.dart';

typedef TrendPoint = ({DateTime t, double v});

class TrendChart extends StatelessWidget {
  const TrendChart({
    super.key,
    required this.title,
    required this.unit,
    required this.color,
    required this.points,
    required this.from,
    required this.days,
    this.decimals = 0,
  });

  final String title;
  final String unit;
  final Color color;
  final List<TrendPoint> points;
  final DateTime from;
  final int days;
  final int decimals;

  @override
  Widget build(BuildContext context) {
    if (points.length < 2) {
      return AppCard(
        title: title,
        child: const Text('Not enough data in this window.', style: AppText.dim),
      );
    }
    final values = points.map((p) => p.v).toList();
    final avg = values.reduce((a, b) => a + b) / values.length;
    final lo = values.reduce(math.min);
    final hi = values.reduce(math.max);
    final pad = math.max(1.0, (hi - lo) * 0.2);
    final spots = [
      for (final p in points) FlSpot(p.t.difference(from).inMinutes / 1440.0, p.v),
    ];
    final tickEvery = math.max(1.0, (days / 4).floorToDouble());

    return AppCard(
      title: title,
      trailing: Text('AVG ${avg.toStringAsFixed(decimals)} $unit', style: AppText.label.copyWith(color: color)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(child: StatTile(label: 'Low', value: lo.toStringAsFixed(decimals), unit: unit)),
            Expanded(child: StatTile(label: 'High', value: hi.toStringAsFixed(decimals), unit: unit)),
            Expanded(child: StatTile(label: 'Latest', value: values.last.toStringAsFixed(decimals), unit: unit, color: color)),
          ]),
          const SizedBox(height: 16),
          SizedBox(
            height: 170,
            child: LineChart(
              LineChartData(
                minX: 0,
                maxX: days.toDouble(),
                minY: lo - pad,
                maxY: hi + pad,
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  topTitles: const AxisTitles(),
                  rightTitles: const AxisTitles(),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 34,
                      getTitlesWidget: (v, meta) => SideTitleWidget(
                        meta: meta,
                        child: Text(v.toStringAsFixed(decimals), style: AppText.tiny),
                      ),
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 24,
                      interval: tickEvery,
                      getTitlesWidget: (v, meta) => SideTitleWidget(
                        meta: meta,
                        child: Text(
                          DateFormat('d MMM').format(from.add(Duration(days: v.round()))),
                          style: AppText.tiny,
                        ),
                      ),
                    ),
                  ),
                ),
                extraLinesData: ExtraLinesData(horizontalLines: [
                  HorizontalLine(y: avg, color: AppColors.textDim, strokeWidth: 1, dashArray: [4, 4]),
                ]),
                lineBarsData: [
                  LineChartBarData(
                    spots: spots,
                    isCurved: true,
                    curveSmoothness: 0.2,
                    color: color,
                    barWidth: 2.5,
                    dotData: const FlDotData(show: false),
                    belowBarData: BarAreaData(show: true, color: color.withAlpha(30)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
