import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'coach_service.dart';

/// API keys and tokens live in the Android Keystore-backed secure storage.
class SecureSettings {
  static const _s = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static const defaultOllamaUrl = 'http://127.0.0.1:11434';

  Future<LlmProvider> loadProvider() async {
    final v = await _s.read(key: 'provider');
    return LlmProvider.values.firstWhere((p) => p.name == v, orElse: () => LlmProvider.ollama);
  }

  Future<void> saveProvider(LlmProvider p) => _s.write(key: 'provider', value: p.name);

  Future<String?> loadApiKey(LlmProvider p) => _s.read(key: 'key_${p.name}');
  Future<void> saveApiKey(LlmProvider p, String v) => v.isEmpty
      ? _s.delete(key: 'key_${p.name}')
      : _s.write(key: 'key_${p.name}', value: v);

  Future<String> loadModel(LlmProvider p) async => (await _s.read(key: 'model_${p.name}')) ?? p.defaultModel;
  Future<void> saveModel(LlmProvider p, String v) => _s.write(key: 'model_${p.name}', value: v);

  Future<String> loadBaseUrl() async => (await _s.read(key: 'ollama_url')) ?? defaultOllamaUrl;
  Future<void> saveBaseUrl(String v) => _s.write(key: 'ollama_url', value: v);

  Future<String?> loadWhoopToken() => _s.read(key: 'whoop_token');
  Future<void> saveWhoopToken(String v) => _s.write(key: 'whoop_token', value: v);

  Future<CoachConfig> loadConfig() async {
    final p = await loadProvider();
    return CoachConfig(
      provider: p,
      model: await loadModel(p),
      baseUrl: await loadBaseUrl(),
      apiKey: await loadApiKey(p),
    );
  }
}
