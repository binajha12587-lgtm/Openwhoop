#!/usr/bin/env bash
# One-shot setup: generates the Android platform folder, patches the manifest
# and Gradle config, installs dependencies and runs Drift code generation.
set -euo pipefail
cd "$(dirname "$0")/.."

command -v flutter >/dev/null || { echo "Flutter SDK not found on PATH."; exit 1; }

if [ ! -d android ]; then
  tmp="$(mktemp -d)"
  cp -r lib pubspec.yaml "$tmp"/
  flutter create --project-name openwhoop --org org.openwhoop --platforms=android .
  rm -rf lib && cp -r "$tmp/lib" lib
  cp "$tmp/pubspec.yaml" pubspec.yaml
  rm -f test/widget_test.dart
fi

MANIFEST=android/app/src/main/AndroidManifest.xml
grep -q 'permission.INTERNET' "$MANIFEST" || \
  perl -0pi -e 's|(<manifest[^>]*>)|$1\n    <uses-permission android:name="android.permission.INTERNET"/>|' "$MANIFEST"
grep -q usesCleartextTraffic "$MANIFEST" || \
  perl -0pi -e 's|<application|<application android:usesCleartextTraffic="true"|' "$MANIFEST"

perl -pi -e 's/android:label="[^"]*"/android:label="OpenWhoop"/' "$MANIFEST"

# flutter_secure_storage needs minSdk 23
for f in android/app/build.gradle android/app/build.gradle.kts; do
  if [ -f "$f" ]; then
    perl -pi -e 's/minSdk = flutter\.minSdkVersion/minSdk = 23/; s/minSdkVersion flutter\.minSdkVersion/minSdkVersion 23/' "$f"
  fi
done

flutter pub get
dart run build_runner build --delete-conflicting-outputs
flutter analyze || true
echo "Setup complete. Build with: flutter build apk --release"
