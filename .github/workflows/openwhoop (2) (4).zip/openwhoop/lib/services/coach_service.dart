import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import '../database/database.dart';
import '../models/dashboard.dart';
import 'whoop_age_calculator.dart';

enum LlmProvider {
  ollama('Local (Ollama-compatible endpoint)', 'llama3.2'),
  openai('OpenAI', 'gpt-4o-mini'),
  anthropic('Anthropic Claude', 'claude-sonnet-5-5'),
  deepseek('DeepSeek', 'deepseek-chat');

  const LlmProvider(this.label, this.defaultModel);
  final String label;
  final String defaultModel;
  bool get needsKey => this != LlmProvider.ollama;
}

class CoachConfig {
  const CoachConfig({
    required this.provider,
    required this.model,
    required this.baseUrl,
    this.apiKey,
  });
  final LlmProvider provider;
  final String model;
  final String baseUrl;
  final String? apiKey;
}

class ChatMessage {
  const ChatMessage({required this.fromUser, required this.text});
  final bool fromUser;
  final String text;
}

/// Builds the system prompt that injects the user's current metrics.
class CoachContextBuilder {
  static String build({
    required Dashboard dashboard,
    required WhoopAgeResult? age,
    required UserProfile profile,
  }) {
    final c = dashboard.cycle;
    final s = dashboard.sleep;
    final t = dashboard.trends;
    final target = strainTargetFor(c?.recoveryScore);
    final b = StringBuffer()
      ..writeln('You are OpenWhoop Coach, a concise, evidence-minded performance and recovery coach.')
      ..writeln('Use the athlete\'s data below to give specific, practical advice (numbers, timing, intensity).')
      ..writeln('You are not a doctor: for symptoms or abnormal readings, suggest seeing a clinician.')
      ..writeln('If data is missing, say so instead of guessing.')
      ..writeln()
      ..writeln('## Profile')
      ..writeln('- Sex: ${profile.sex ?? 'unknown'}; birth year: ${profile.birthYear ?? 'unknown'}')
      ..writeln()
      ..writeln('## Today${c == null ? '' : ' (${DateFormat('EEE d MMM').format(c.start)})'}')
      ..writeln('- Recovery: ${_f(c?.recoveryScore)}%')
      ..writeln('- HRV: ${_f(c?.hrv)} ms; resting HR: ${_f(c?.restingHr)} bpm')
      ..writeln('- SpO2: ${_f(c?.spo2, 1)}%; skin temp: ${_f(c?.skinTemp, 1)} C')
      ..writeln('- Day strain so far: ${_f(c?.dayStrain, 1)} / 21 '
          '(suggested range ${target.lo.toStringAsFixed(0)}-${target.hi.toStringAsFixed(0)})')
      ..writeln()
      ..writeln('## Last sleep')
      ..writeln('- Asleep: ${_dur(s?.asleepMin)}; performance: ${_f(s?.performance)}%; efficiency: ${_f(s?.efficiency)}%')
      ..writeln('- Light ${_dur(s?.lightMin)}, deep ${_dur(s?.deepMin)}, REM ${_dur(s?.remMin)}, awake ${_dur(s?.awakeMin)}')
      ..writeln('- Sleep need: ${_dur(s?.needMin)}; sleep debt: ${_dur(s?.debtMin)}')
      ..writeln()
      ..writeln('## Last 7 days (${dashboard.week.days} days of data)')
      ..writeln('- Recovery ${_f(dashboard.week.recovery)}%, HRV ${_f(dashboard.week.hrv)} ms, '
          'RHR ${_f(dashboard.week.rhr)} bpm, strain ${_f(dashboard.week.strain, 1)}, '
          'sleep performance ${_f(dashboard.week.sleepPerformance)}%')
      ..writeln()
      ..writeln('## 3-month averages (${t.days} days of data)')
      ..writeln('- Recovery ${_f(t.recovery)}%, HRV ${_f(t.hrv)} ms, RHR ${_f(t.rhr)} bpm, strain ${_f(t.strain, 1)}')
      ..writeln('- Sleep performance ${_f(t.sleepPerformance)}%, avg sleep debt ${_dur(t.sleepDebtMin)}')
      ..writeln('- SpO2 ${_f(t.spo2, 1)}%, respiratory rate ${_f(t.respRate, 1)} rpm')
      ..writeln();
    if (age != null && age.sufficient) {
      b.writeln('## Fitness age (heuristic)');
      b.writeln('- Estimated ${age.whoopAge.toStringAsFixed(1)} vs chronological ${age.chronologicalAge.toStringAsFixed(1)}');
      for (final f in age.factors) {
        b.writeln('- ${f.name}: ${f.deltaYears >= 0 ? '+' : ''}${f.deltaYears.toStringAsFixed(1)} y (${f.detail})');
      }
    } else {
      b.writeln('## Fitness age: not available (needs profile and at least 14 days of data).');
    }
    return b.toString();
  }

  static String _f(double? v, [int dp = 0]) => v == null ? 'n/a' : v.toStringAsFixed(dp);
  static String _dur(double? m) => m == null ? 'n/a' : '${m ~/ 60}h ${(m % 60).round()}m';
}

class CoachService {
  CoachService({http.Client? client}) : _http = client ?? http.Client();
  final http.Client _http;

  Future<String> send({
    required CoachConfig config,
    required String systemPrompt,
    required List<ChatMessage> history,
  }) async {
    if (config.provider.needsKey && (config.apiKey == null || config.apiKey!.isEmpty)) {
      throw Exception('Add your ${config.provider.label} API key in Settings first.');
    }
    final msgs = [
      for (final m in history) {'role': m.fromUser ? 'user' : 'assistant', 'content': m.text},
    ];
    switch (config.provider) {
      case LlmProvider.ollama:
        final base = config.baseUrl.replaceAll(RegExp(r'/+$'), '');
        final j = await _post(
          Uri.parse('$base/api/chat'),
          {'Content-Type': 'application/json'},
          {
            'model': config.model,
            'stream': false,
            'messages': [
              {'role': 'system', 'content': systemPrompt},
              ...msgs,
            ],
          },
          const Duration(minutes: 3),
        );
        return (j['message']?['content'] as String?)?.trim() ?? _empty();
      case LlmProvider.openai:
      case LlmProvider.deepseek:
        final url = config.provider == LlmProvider.openai
            ? 'https://api.openai.com/v1/chat/completions'
            : 'https://api.deepseek.com/chat/completions';
        final j = await _post(
          Uri.parse(url),
          {'Content-Type': 'application/json', 'Authorization': 'Bearer ${config.apiKey}'},
          {
            'model': config.model,
            'messages': [
              {'role': 'system', 'content': systemPrompt},
              ...msgs,
            ],
          },
          const Duration(seconds: 90),
        );
        final choices = j['choices'] as List?;
        return (choices != null && choices.isNotEmpty
                ? choices.first['message']?['content'] as String?
                : null)
                ?.trim() ??
            _empty();
      case LlmProvider.anthropic:
        final j = await _post(
          Uri.parse('https://api.anthropic.com/v1/messages'),
          {
            'Content-Type': 'application/json',
            'x-api-key': config.apiKey!,
            'anthropic-version': '2023-06-01',
          },
          {
            'model': config.model,
            'max_tokens': 1024,
            'system': systemPrompt,
            'messages': msgs,
          },
          const Duration(seconds: 90),
        );
        final content = j['content'] as List?;
        final text = content
            ?.whereType<Map>()
            .where((e) => e['type'] == 'text')
            .map((e) => e['text'] as String)
            .join('\n');
        return (text == null || text.trim().isEmpty) ? _empty() : text.trim();
    }
  }

  String _empty() => 'The model returned an empty reply.';

  Future<Map<String, dynamic>> _post(
    Uri uri,
    Map<String, String> headers,
    Map<String, dynamic> body,
    Duration timeout,
  ) async {
    final res = await _http.post(uri, headers: headers, body: jsonEncode(body)).timeout(timeout);
    final decoded = utf8.decode(res.bodyBytes);
    if (res.statusCode < 200 || res.statusCode >= 300) {
      var msg = decoded;
      try {
        final e = jsonDecode(decoded);
        msg = (e['error'] is Map ? e['error']['message'] : e['error'])?.toString() ?? decoded;
      } catch (_) {}
      throw Exception('HTTP ${res.statusCode}: ${msg.length > 300 ? msg.substring(0, 300) : msg}');
    }
    return jsonDecode(decoded) as Map<String, dynamic>;
  }
}
