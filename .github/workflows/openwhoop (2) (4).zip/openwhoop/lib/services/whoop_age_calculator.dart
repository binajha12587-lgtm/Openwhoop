import 'dart:math' as math;

import '../database/database.dart';
import '../models/dashboard.dart';

class AgeFactor {
  const AgeFactor(this.name, this.deltaYears, this.detail);
  final String name;

  /// Negative = makes you biologically younger, positive = older.
  final double deltaYears;
  final String detail;
  bool get younger => deltaYears < -0.05;
  bool get older => deltaYears > 0.05;
}

class WhoopAgeResult {
  const WhoopAgeResult({
    required this.chronologicalAge,
    required this.whoopAge,
    required this.factors,
    required this.sampleDays,
    required this.sufficient,
  });
  final double chronologicalAge;
  final double whoopAge;
  final List<AgeFactor> factors;
  final int sampleDays;
  final bool sufficient;
  double get delta => whoopAge - chronologicalAge;
}

/// Heuristic biological-age estimate over a rolling 3-month window.
/// This is an open, transparent approximation and not a medical measurement.
class WhoopAgeCalculator {
  static const windowDays = 90;
  static const minDays = 14;

  WhoopAgeResult calculate({
    required double chronologicalAge,
    required List<Cycle> cycles,
    required List<Sleep> sleeps,
    DateTime? now,
  }) {
    final end = now ?? DateTime.now();
    final from = end.subtract(const Duration(days: windowDays));
    final cs = cycles.where((c) => !c.start.isBefore(from) && !c.start.isAfter(end)).toList();
    final ss = sleeps.where((s) => !s.isNap && !s.onset.isBefore(from) && !s.onset.isAfter(end)).toList();

    if (cs.length < minDays) {
      return WhoopAgeResult(
        chronologicalAge: chronologicalAge,
        whoopAge: chronologicalAge,
        factors: const [],
        sampleDays: cs.length,
        sufficient: false,
      );
    }

    final factors = <AgeFactor>[
      _recovery(cs, chronologicalAge),
      _strain(cs),
      _sleep(ss),
      _respiratory(cs, ss),
    ];
    final total = _clamp(factors.fold<double>(0, (a, f) => a + f.deltaYears), -15, 15);
    return WhoopAgeResult(
      chronologicalAge: chronologicalAge,
      whoopAge: chronologicalAge + total,
      factors: factors,
      sampleDays: cs.length,
      sufficient: true,
    );
  }

  // --- Recovery consistency: HRV vs. age norm + HRV stability ---------------
  AgeFactor _recovery(List<Cycle> cs, double age) {
    final hrvs = cs.map((c) => c.hrv).whereType<double>().toList();
    if (hrvs.length < 7) {
      return const AgeFactor('Recovery consistency', 0, 'Not enough HRV data yet.');
    }
    final avg = hrvs.reduce((a, b) => a + b) / hrvs.length;
    final expected = math.max(25.0, 100 - 0.95 * age);
    var delta = _clamp((expected - avg) / expected * 14, -6, 8);
    final cv = _std(hrvs) / avg;
    delta += _clamp((cv - 0.15) * 10, -1, 2);
    final vs = avg >= expected ? 'above' : 'below';
    return AgeFactor(
      'Recovery consistency',
      delta,
      'Average HRV ${avg.round()} ms is $vs the ~${expected.round()} ms typical for your age; '
      'day-to-day variability ${(cv * 100).round()}%.',
    );
  }

  // --- Strain balance: training load matched to recovery -------------------
  AgeFactor _strain(List<Cycle> cs) {
    final pairs = cs.where((c) => c.dayStrain != null && c.recoveryScore != null).toList();
    if (pairs.length < 7) {
      return const AgeFactor('Strain balance', 0, 'Not enough strain and recovery pairs yet.');
    }
    var within = 0;
    var over = 0;
    for (final c in pairs) {
      final t = strainTargetFor(c.recoveryScore);
      final s = c.dayStrain!;
      if (s >= t.lo - 1 && s <= t.hi + 0.5) within++;
      if (s > t.hi + 2) over++;
    }
    final withinRate = within / pairs.length;
    final overRate = over / pairs.length;
    final delta = _clamp((0.55 - withinRate) * 8 + overRate * 6, -3, 6);
    return AgeFactor(
      'Strain balance',
      delta,
      '${(withinRate * 100).round()}% of days matched strain to recovery; '
      '${(overRate * 100).round()}% pushed well past the recommended range.',
    );
  }

  // --- Sleep quality: performance + debt -----------------------------------
  AgeFactor _sleep(List<Sleep> ss) {
    final perfs = ss.map((s) => s.performance).whereType<double>().toList();
    if (perfs.length < 7) {
      return const AgeFactor('Sleep quality', 0, 'Not enough sleep data yet.');
    }
    final perf = perfs.reduce((a, b) => a + b) / perfs.length;
    final debt = avgOf(ss.map((s) => s.debtMin)) ?? 0;
    final delta = _clamp((85 - perf) * 0.12, -3, 5) + _clamp((debt - 30) / 60, 0, 2.5);
    return AgeFactor(
      'Sleep quality',
      delta,
      'Average sleep performance ${perf.round()}% with ${debt.round()} min average sleep debt.',
    );
  }

  // --- Respiratory health: SpO2, RHR anomalies, respiratory-rate stability --
  AgeFactor _respiratory(List<Cycle> cs, List<Sleep> ss) {
    final spo2 = avgOf(cs.map((c) => c.spo2));
    final rhrs = cs.map((c) => c.restingHr).whereType<double>().toList();
    final resp = ss.map((s) => s.respRate).whereType<double>().toList();
    if (spo2 == null && rhrs.length < 7) {
      return const AgeFactor('Respiratory health', 0, 'Not enough SpO2 or resting heart rate data yet.');
    }
    var delta = 0.0;
    final notes = <String>[];
    if (spo2 != null) {
      delta += _clamp((95.5 - spo2) * 1.2, -1, 4);
      notes.add('SpO2 averages ${spo2.toStringAsFixed(1)}%');
    }
    if (rhrs.length >= 7) {
      final base = rhrs.reduce((a, b) => a + b) / rhrs.length;
      final anomalies = rhrs.where((r) => r > base + 7).length / rhrs.length;
      delta += _clamp(anomalies * 6, 0, 3);
      notes.add('${(anomalies * 100).round()}% of days with elevated resting HR');
    }
    if (resp.length >= 7) {
      delta += _clamp((_std(resp) - 0.8) * 1.5, 0, 2);
      notes.add('respiratory rate spread ${_std(resp).toStringAsFixed(1)} rpm');
    }
    return AgeFactor('Respiratory health', delta, '${notes.join('; ')}.');
  }

  double _std(List<double> v) {
    if (v.length < 2) return 0;
    final m = v.reduce((a, b) => a + b) / v.length;
    final ss = v.fold<double>(0, (a, x) => a + (x - m) * (x - m));
    return math.sqrt(ss / (v.length - 1));
  }

  double _clamp(double v, double lo, double hi) => math.max(lo, math.min(hi, v));
}
