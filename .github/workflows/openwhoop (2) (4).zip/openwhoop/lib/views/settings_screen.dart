import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../providers/providers.dart';
import '../services/coach_service.dart';
import '../services/data_importer.dart';
import '../services/secure_settings.dart';
import '../services/whoop_api_sync.dart';
import '../theme.dart';
import '../widgets/cards.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  final _birthYear = TextEditingController();
  final _model = TextEditingController();
  final _baseUrl = TextEditingController(text: SecureSettings.defaultOllamaUrl);
  final _apiKey = TextEditingController();
  final _token = TextEditingController();
  String? _sex;
  LlmProvider _provider = LlmProvider.ollama;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [_birthYear, _model, _baseUrl, _apiKey, _token]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final db = ref.read(databaseProvider);
    final store = ref.read(secureSettingsProvider);
    final year = await db.getMetric('birth_year');
    final sex = await db.getMetric('sex');
    final provider = await store.loadProvider();
    final base = await store.loadBaseUrl();
    final token = await store.loadWhoopToken();
    if (!mounted) return;
    setState(() {
      _birthYear.text = year ?? '';
      _sex = sex;
      _baseUrl.text = base;
      _token.text = token ?? '';
    });
    await _selectProvider(provider);
  }

  Future<void> _selectProvider(LlmProvider p) async {
    final store = ref.read(secureSettingsProvider);
    final model = await store.loadModel(p);
    final key = await store.loadApiKey(p);
    if (!mounted) return;
    setState(() {
      _provider = p;
      _model.text = model;
      _apiKey.text = key ?? '';
    });
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  void _refresh() => ref.read(refreshProvider.notifier).state++;

  Future<void> _saveProfile() async {
    final year = int.tryParse(_birthYear.text.trim());
    if (year == null || year < 1900 || year > DateTime.now().year) {
      _toast('Enter a valid birth year.');
      return;
    }
    final db = ref.read(databaseProvider);
    await db.setMetric('birth_year', '$year');
    if (_sex != null) await db.setMetric('sex', _sex!);
    _refresh();
    _toast('Profile saved.');
  }

  Future<void> _import() async {
    final picked = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: const ['zip', 'csv', 'json'],
      withData: true,
    );
    if (picked == null) return;
    setState(() => _busy = true);
    try {
      final files = <String, Uint8List>{
        for (final f in picked.files)
          if (f.bytes != null) f.name: f.bytes!,
      };
      final report = await DataImporter(ref.read(databaseProvider)).importFiles(files);
      _refresh();
      _toast(report.toString());
    } catch (e) {
      _toast('Import failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _syncApi() async {
    final token = _token.text.trim();
    if (token.isEmpty) {
      _toast('Paste an access token first.');
      return;
    }
    setState(() => _busy = true);
    try {
      await ref.read(secureSettingsProvider).saveWhoopToken(token);
      final report = await WhoopApiSync(ref.read(databaseProvider)).sync(token, days: 90);
      _refresh();
      _toast('Synced: ${report.cycles} cycles, ${report.sleeps} sleeps, ${report.workouts} workouts.');
    } catch (e) {
      _toast('Sync failed: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveAi() async {
    final store = ref.read(secureSettingsProvider);
    await store.saveProvider(_provider);
    await store.saveModel(_provider, _model.text.trim().isEmpty ? _provider.defaultModel : _model.text.trim());
    if (_provider == LlmProvider.ollama) {
      await store.saveBaseUrl(_baseUrl.text.trim());
    } else {
      await store.saveApiKey(_provider, _apiKey.text.trim());
    }
    _refresh();
    _toast('Coach settings saved.');
  }

  Future<void> _clear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete all imported data?'),
        content: const Text('Cycles, sleeps and workouts stored on this device will be removed. Your profile and keys stay.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    await ref.read(databaseProvider).clearActivityData();
    _refresh();
    _toast('Data deleted.');
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 14),
          child: Text('SETTINGS', style: AppText.label),
        ),
        if (_busy) const Padding(padding: EdgeInsets.only(bottom: 12), child: LinearProgressIndicator()),
        AppCard(
          title: 'Profile',
          child: Column(children: [
            TextField(
              controller: _birthYear,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Birth year'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _sex,
              decoration: const InputDecoration(labelText: 'Sex'),
              items: const [
                DropdownMenuItem(value: 'female', child: Text('Female')),
                DropdownMenuItem(value: 'male', child: Text('Male')),
                DropdownMenuItem(value: 'other', child: Text('Other / prefer not to say')),
              ],
              onChanged: (v) => setState(() => _sex = v),
            ),
            const SizedBox(height: 12),
            Align(alignment: Alignment.centerRight, child: FilledButton(onPressed: _saveProfile, child: const Text('Save'))),
          ]),
        ),
        AppCard(
          title: 'Stored data',
          child: ref.watch(dataStatsProvider).when(
                loading: () => const Text('Loading…', style: AppText.dim),
                error: (e, _) => Text('$e', style: AppText.dim),
                data: (s) {
                  final f = DateFormat('d MMM y');
                  return Column(children: [
                    KeyValueRow('Cycles', '${s.cycles}'),
                    KeyValueRow('Sleeps', '${s.sleeps}'),
                    KeyValueRow('Workouts', '${s.workouts}'),
                    KeyValueRow(
                      'Range',
                      s.first == null ? '--' : '${f.format(s.first!)} – ${f.format(s.last!)}',
                    ),
                  ]);
                },
              ),
        ),
        AppCard(
          title: 'Import data',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(
              'Select the export zip you downloaded from your WHOOP account, or individual '
              'physiological_cycles / sleeps / workouts CSV or JSON files.',
              style: AppText.dim,
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _busy ? null : _import,
              icon: const Icon(Icons.upload_file),
              label: const Text('Choose files'),
            ),
          ]),
        ),
        AppCard(
          title: 'API sync (optional)',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(
              'Paste a developer-API access token to pull the last 90 days. Tokens expire after about an hour.',
              style: AppText.dim,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _token,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Access token'),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _busy ? null : _syncApi,
              icon: const Icon(Icons.sync),
              label: const Text('Sync now'),
            ),
          ]),
        ),
        AppCard(
          title: 'AI coach provider',
          child: Column(children: [
            DropdownButtonFormField<LlmProvider>(
              value: _provider,
              decoration: const InputDecoration(labelText: 'Provider'),
              items: [for (final p in LlmProvider.values) DropdownMenuItem(value: p, child: Text(p.label))],
              onChanged: (p) {
                if (p != null) _selectProvider(p);
              },
            ),
            const SizedBox(height: 12),
            TextField(controller: _model, decoration: const InputDecoration(labelText: 'Model')),
            const SizedBox(height: 12),
            if (_provider == LlmProvider.ollama)
              TextField(
                controller: _baseUrl,
                keyboardType: TextInputType.url,
                decoration: const InputDecoration(
                  labelText: 'Endpoint URL',
                  helperText: 'e.g. http://127.0.0.1:11434 (Termux) or http://192.168.x.x:11434',
                ),
              )
            else
              TextField(
                controller: _apiKey,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'API key',
                  helperText: 'Stored in Android Keystore-backed secure storage.',
                ),
              ),
            const SizedBox(height: 12),
            Align(alignment: Alignment.centerRight, child: FilledButton(onPressed: _saveAi, child: const Text('Save'))),
          ]),
        ),
        AppCard(
          title: 'Danger zone',
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(foregroundColor: AppColors.red),
            onPressed: _clear,
            icon: const Icon(Icons.delete_outline),
            label: const Text('Delete imported data'),
          ),
        ),
      ],
    );
  }
}
