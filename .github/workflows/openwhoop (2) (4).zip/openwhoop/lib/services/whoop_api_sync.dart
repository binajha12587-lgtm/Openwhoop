import 'dart:convert';

import 'package:drift/drift.dart' show Value;
import 'package:http/http.dart' as http;

import '../database/database.dart';
import 'data_importer.dart';

/// Optional bridge: pulls recent records from the WHOOP developer API using a
/// bearer token pasted by the user (tokens expire after roughly an hour).
class WhoopApiSync {
  WhoopApiSync(this._db, {http.Client? client}) : _http = client ?? http.Client();
  final AppDatabase _db;
  final http.Client _http;
  static const _base = 'https://api.prod.whoop.com/developer/v1';

  Future<ImportReport> sync(String token, {int days = 30}) async {
    final since = DateTime.now().subtract(Duration(days: days));
    final cycleJson = await _fetchAll('/cycle', token, since);
    final recoveryJson = await _fetchAll('/recovery', token, since);
    final sleepJson = await _fetchAll('/activity/sleep', token, since);
    final workoutJson = await _fetchAll('/activity/workout', token, since);

    final recoveryByCycle = {for (final r in recoveryJson) '${r['cycle_id']}': _m(r['score'])};

    final cycles = <CyclesCompanion>[];
    for (final c in cycleJson) {
      final start = _t(c['start']);
      if (start == null) continue;
      final score = _m(c['score']);
      final rec = recoveryByCycle['${c['id']}'];
      final kj = _n(score?['kilojoule']);
      cycles.add(CyclesCompanion(
        start: Value(start),
        end: Value(_t(c['end'])),
        dayStrain: Value(_n(score?['strain'])),
        energyKcal: Value(kj == null ? null : kj / 4.184),
        avgHr: Value(_n(score?['average_heart_rate'])),
        maxHr: Value(_n(score?['max_heart_rate'])),
        recoveryScore: Value(_n(rec?['recovery_score'])),
        restingHr: Value(_n(rec?['resting_heart_rate'])),
        hrv: Value(_n(rec?['hrv_rmssd_milli'])),
        spo2: Value(_n(rec?['spo2_percentage'])),
        skinTemp: Value(_n(rec?['skin_temp_celsius'])),
      ));
    }

    final sleeps = <SleepsCompanion>[];
    for (final s in sleepJson) {
      final onset = _t(s['start']);
      if (onset == null) continue;
      final score = _m(s['score']);
      final st = _m(score?['stage_summary']);
      final need = _m(score?['sleep_needed']);
      double? min(dynamic v) => _n(v) == null ? null : _n(v)! / 60000.0;
      final light = min(st?['total_light_sleep_time_milli']);
      final deep = min(st?['total_slow_wave_sleep_time_milli']);
      final rem = min(st?['total_rem_sleep_time_milli']);
      final needTotal = [
        min(need?['baseline_milli']),
        min(need?['need_from_sleep_debt_milli']),
        min(need?['need_from_recent_strain_milli']),
        min(need?['need_from_recent_nap_milli']),
      ].whereType<double>().fold<double>(0, (a, b) => a + b);
      sleeps.add(SleepsCompanion(
        onset: Value(onset),
        wake: Value(_t(s['end'])),
        isNap: Value(s['nap'] == true),
        performance: Value(_n(score?['sleep_performance_percentage'])),
        efficiency: Value(_n(score?['sleep_efficiency_percentage'])),
        consistency: Value(_n(score?['sleep_consistency_percentage'])),
        respRate: Value(_n(score?['respiratory_rate'])),
        inBedMin: Value(min(st?['total_in_bed_time_milli'])),
        awakeMin: Value(min(st?['total_awake_time_milli'])),
        lightMin: Value(light),
        deepMin: Value(deep),
        remMin: Value(rem),
        asleepMin: Value([light, deep, rem].whereType<double>().fold<double>(0, (a, b) => a + b)),
        needMin: Value(needTotal == 0 ? null : needTotal),
        debtMin: Value(min(need?['need_from_sleep_debt_milli'])),
      ));
    }

    final workouts = <WorkoutsCompanion>[];
    for (final w in workoutJson) {
      final start = _t(w['start']);
      if (start == null) continue;
      final end = _t(w['end']);
      final score = _m(w['score']);
      final zones = _m(score?['zone_duration']);
      const keys = [
        'zone_zero_milli', 'zone_one_milli', 'zone_two_milli',
        'zone_three_milli', 'zone_four_milli', 'zone_five_milli',
      ];
      final ms = keys.map((k) => _n(zones?[k]) ?? 0).toList();
      final total = ms.fold<double>(0, (a, b) => a + b);
      double? pct(int i) => total <= 0 ? null : ms[i] / total * 100;
      final kj = _n(score?['kilojoule']);
      final dist = _n(score?['distance_meter']);
      workouts.add(WorkoutsCompanion(
        start: Value(start),
        end: Value(end),
        durationMin: Value(end == null ? null : end.difference(start).inSeconds / 60.0),
        activity: Value((w['sport_name'] as String?) ?? 'Activity'),
        strain: Value(_n(score?['strain'])),
        energyKcal: Value(kj == null ? null : kj / 4.184),
        avgHr: Value(_n(score?['average_heart_rate'])),
        maxHr: Value(_n(score?['max_heart_rate'])),
        zone1: Value(pct(1)),
        zone2: Value(pct(2)),
        zone3: Value(pct(3)),
        zone4: Value(pct(4)),
        zone5: Value(pct(5)),
        distanceM: Value(dist),
        altitudeGainM: Value(_n(score?['altitude_gain_meter'])),
        hasGps: Value(dist != null && dist > 0),
      ));
    }

    await _db.upsertCycles(cycles);
    await _db.upsertSleeps(sleeps);
    await _db.upsertWorkouts(workouts);
    final report = ImportReport()
      ..cycles = cycles.length
      ..sleeps = sleeps.length
      ..workouts = workouts.length;
    return report;
  }

  Future<List<Map<String, dynamic>>> _fetchAll(String path, String token, DateTime since) async {
    final out = <Map<String, dynamic>>[];
    String? next;
    do {
      final uri = Uri.parse('$_base$path').replace(queryParameters: {
        'limit': '25',
        'start': since.toUtc().toIso8601String(),
        if (next != null) 'nextToken': next,
      });
      final res = await _http.get(uri, headers: {'Authorization': 'Bearer $token'});
      if (res.statusCode == 401) {
        throw Exception('Token rejected (401). Tokens expire after about an hour.');
      }
      if (res.statusCode != 200) {
        throw Exception('HTTP ${res.statusCode} from $path');
      }
      final j = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      for (final r in (j['records'] as List? ?? const [])) {
        if (r is Map<String, dynamic>) out.add(r);
      }
      final tok = j['next_token'] as String?;
      next = (tok == null || tok.isEmpty) ? null : tok;
    } while (next != null);
    return out;
  }

  Map<String, dynamic>? _m(dynamic v) => v is Map<String, dynamic> ? v : null;
  double? _n(dynamic v) => v is num ? v.toDouble() : null;
  DateTime? _t(dynamic v) => v is String ? DateTime.tryParse(v)?.toLocal() : null;
}
