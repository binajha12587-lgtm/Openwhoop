import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/providers.dart';
import '../services/coach_service.dart';
import '../theme.dart';

class AiCoachScreen extends ConsumerStatefulWidget {
  const AiCoachScreen({super.key});

  @override
  ConsumerState<AiCoachScreen> createState() => _AiCoachScreenState();
}

class _AiCoachScreenState extends ConsumerState<AiCoachScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();

  static const _suggestions = [
    'How should I train today?',
    'Why is my recovery low?',
    'How can I reduce my sleep debt?',
  ];

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _send(String text) {
    if (text.trim().isEmpty) return;
    ref.read(coachControllerProvider.notifier).send(text);
    _input.clear();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(coachControllerProvider);
    final config = ref.watch(coachConfigProvider).valueOrNull;

    ref.listen(coachControllerProvider, (prev, next) {
      if (next.error != null && next.error != prev?.error && next.retryText != null) {
        _input.text = next.retryText!;
        _input.selection = TextSelection.collapsed(offset: _input.text.length);
      }
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) {
          _scroll.animateTo(
            _scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
          );
        }
      });
    });

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 12, 8),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('AI COACH', style: AppText.label),
                    const SizedBox(height: 2),
                    Text(
                      config == null ? '' : '${config.provider.label} · ${config.model}',
                      style: AppText.dim,
                    ),
                  ],
                ),
              ),
              if (state.messages.isNotEmpty)
                IconButton(
                  tooltip: 'New chat',
                  icon: const Icon(Icons.refresh, color: AppColors.textDim),
                  onPressed: () => ref.read(coachControllerProvider.notifier).clear(),
                ),
            ],
          ),
        ),
        Expanded(
          child: state.messages.isEmpty
              ? _Intro(onPick: _send)
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  itemCount: state.messages.length + (state.loading ? 1 : 0),
                  itemBuilder: (context, i) {
                    if (i >= state.messages.length) return const _Bubble(text: '…', fromUser: false);
                    final m = state.messages[i];
                    return _Bubble(text: m.text, fromUser: m.fromUser);
                  },
                ),
        ),
        if (state.error != null)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.red.withAlpha(30),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(state.error!, style: AppText.body.copyWith(color: AppColors.red)),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: TextField(
                  controller: _input,
                  minLines: 1,
                  maxLines: 4,
                  textInputAction: TextInputAction.send,
                  onSubmitted: _send,
                  decoration: const InputDecoration(hintText: 'Ask your coach…'),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                style: IconButton.styleFrom(backgroundColor: AppColors.sleep),
                onPressed: state.loading ? null : () => _send(_input.text),
                icon: const Icon(Icons.arrow_upward),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Intro extends StatelessWidget {
  const _Intro({required this.onPick});
  final void Function(String) onPick;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Your coach sees today\'s recovery, strain, sleep, 3-month trends and fitness age.',
                textAlign: TextAlign.center,
                style: AppText.dim,
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: [
                  for (final s in _AiCoachScreenState._suggestions)
                    ActionChip(label: Text(s), onPressed: () => onPick(s)),
                ],
              ),
            ],
          ),
        ),
      );
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.text, required this.fromUser});
  final String text;
  final bool fromUser;

  @override
  Widget build(BuildContext context) => Align(
        alignment: fromUser ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: fromUser ? AppColors.sleep.withAlpha(70) : AppColors.card,
            borderRadius: BorderRadius.circular(16),
          ),
          child: SelectableText(text, style: AppText.body),
        ),
      );
}
