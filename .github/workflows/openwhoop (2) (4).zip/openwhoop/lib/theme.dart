import 'package:flutter/material.dart';

class AppColors {
  static const background = Color(0xFF000000);
  static const card = Color(0xFF1F1F1F);
  static const recovery = Color(0xFF1CC88A);
  static const strain = Color(0xFFFF5A36);
  static const sleep = Color(0xFFA855F7);
  static const yellow = Color(0xFFFFD60A);
  static const red = Color(0xFFFF3B30);
  static const textPrimary = Color(0xFFFFFFFF);
  static const textDim = Color(0xFF8E8E93);
  static const track = Color(0xFF2C2C2E);

  /// Red / yellow / green recovery band.
  static Color recoveryBand(double? pct) {
    if (pct == null) return textDim;
    if (pct >= 67) return recovery;
    if (pct >= 34) return yellow;
    return red;
  }
}

class AppText {
  static const label = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w700,
    letterSpacing: 1.3,
    color: AppColors.textDim,
  );
  static const big = TextStyle(
    fontSize: 38,
    fontWeight: FontWeight.w800,
    color: AppColors.textPrimary,
    height: 1.05,
  );
  static const medium = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
  );
  static const body = TextStyle(fontSize: 14, color: AppColors.textPrimary, height: 1.35);
  static const dim = TextStyle(fontSize: 13, color: AppColors.textDim, height: 1.35);
  static const tiny = TextStyle(fontSize: 10, color: AppColors.textDim);
}

ThemeData buildTheme() {
  const scheme = ColorScheme.dark(
    surface: AppColors.background,
    primary: AppColors.recovery,
    secondary: AppColors.sleep,
    error: AppColors.red,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.background,
    canvasColor: AppColors.background,
    dividerColor: AppColors.track,
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.black,
      indicatorColor: AppColors.card,
      labelTextStyle: const WidgetStatePropertyAll(
        TextStyle(fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.5),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.card,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    ),
  );
}
