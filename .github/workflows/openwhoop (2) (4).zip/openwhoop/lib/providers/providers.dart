import 'dart:async';
import 'dart:io';

import 'package:drift/drift.dart' show Value;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;

import '../database/database.dart';
import '../models/dashboard.dart';
import '../services/coach_service.dart';
import '../services/secure_settings.dart';
import '../services/whoop_age_calculator.dart';

final databaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase();
  ref.onDispose(db.close);
  return db;
});

/// Bump after imports / profile edits so every data provider refetches.
final refreshProvider = StateProvider<int>((ref) => 0);

final secureSettingsProvider = Provider<SecureSettings>((ref) => SecureSettings());

final coachConfigProvider = FutureProvider<CoachConfig>((ref) {
  ref.watch(refreshProvider);
  return ref.watch(secureSettingsProvider).loadConfig();
});

/// End of the data range: the day after the newest cycle (or now when empty).
/// Windows are anchored here so older exports still render.
final anchorProvider = FutureProvider<DateTime>((ref) async {
  ref.watch(refreshProvider);
  final latest = await ref.watch(databaseProvider).latestCycle();
  return latest?.start.add(const Duration(days: 1)) ?? DateTime.now();
});

final dataStatsProvider = FutureProvider<DataStats>((ref) {
  ref.watch(refreshProvider);
  return ref.watch(databaseProvider).stats();
});

final profileProvider = FutureProvider<UserProfile>((ref) async {
  ref.watch(refreshProvider);
  final db = ref.watch(databaseProvider);
  final year = int.tryParse(await db.getMetric('birth_year') ?? '');
  return UserProfile(birthYear: year, sex: await db.getMetric('sex'));
});

final dashboardProvider = FutureProvider<Dashboard>((ref) async {
  ref.watch(refreshProvider);
  final db = ref.watch(databaseProvider);
  final anchor = await ref.watch(anchorProvider.future);
  final from = anchor.subtract(const Duration(days: 90));
  final weekFrom = anchor.subtract(const Duration(days: 7));
  final cycles = await db.cyclesBetween(from, anchor);
  final sleeps = await db.sleepsBetween(from, anchor);

  var cycle = await db.latestCycle();
  DateTime? recoveryDate;
  if (cycle != null && cycle.recoveryScore == null) {
    // Today's cycle is not scored yet: show the latest scored recovery instead.
    final scored = await db.latestRecoveredCycle();
    if (scored != null) {
      recoveryDate = scored.start;
      cycle = cycle.copyWith(
        recoveryScore: Value(scored.recoveryScore),
        restingHr: Value(scored.restingHr),
        hrv: Value(scored.hrv),
        skinTemp: Value(scored.skinTemp),
        spo2: Value(scored.spo2),
      );
    }
  }

  return Dashboard(
    cycle: cycle,
    sleep: await db.latestSleep(),
    trends: TrendSummary.from(cycles, sleeps),
    week: TrendSummary.from(
      cycles.where((c) => !c.start.isBefore(weekFrom)).toList(),
      sleeps.where((s) => !s.onset.isBefore(weekFrom)).toList(),
    ),
    recoveryDate: recoveryDate,
  );
});

final trendCyclesProvider = FutureProvider.family<List<Cycle>, int>((ref, days) async {
  ref.watch(refreshProvider);
  final anchor = await ref.watch(anchorProvider.future);
  return ref.watch(databaseProvider).cyclesBetween(anchor.subtract(Duration(days: days)), anchor);
});

final trendSleepsProvider = FutureProvider.family<List<Sleep>, int>((ref, days) async {
  ref.watch(refreshProvider);
  final anchor = await ref.watch(anchorProvider.future);
  return ref.watch(databaseProvider).sleepsBetween(anchor.subtract(Duration(days: days)), anchor);
});

final workoutsProvider = FutureProvider<List<Workout>>((ref) async {
  ref.watch(refreshProvider);
  final anchor = await ref.watch(anchorProvider.future);
  return ref.watch(databaseProvider).workoutsBetween(anchor.subtract(const Duration(days: 60)), anchor);
});

/// Null until a birth year is set in Settings.
final whoopAgeProvider = FutureProvider<WhoopAgeResult?>((ref) async {
  ref.watch(refreshProvider);
  final profile = await ref.watch(profileProvider.future);
  final anchor = await ref.watch(anchorProvider.future);
  final age = profile.ageAt(anchor);
  if (age == null) return null;
  final db = ref.watch(databaseProvider);
  final from = anchor.subtract(const Duration(days: WhoopAgeCalculator.windowDays));
  return WhoopAgeCalculator().calculate(
    chronologicalAge: age,
    cycles: await db.cyclesBetween(from, anchor),
    sleeps: await db.sleepsBetween(from, anchor),
    now: anchor,
  );
});

// ---- AI coach chat ------------------------------------------------------

class CoachState {
  const CoachState({
    this.messages = const [],
    this.loading = false,
    this.error,
    this.retryText,
  });
  final List<ChatMessage> messages;
  final bool loading;
  final String? error;

  /// The message that failed to send, so the UI can put it back in the input box.
  final String? retryText;
}

class CoachController extends StateNotifier<CoachState> {
  CoachController(this._ref) : super(const CoachState());
  final Ref _ref;
  final _service = CoachService();
  static const _maxHistory = 20;

  Future<void> send(String text) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty || state.loading) return;
    final history = [...state.messages, ChatMessage(fromUser: true, text: trimmed)];
    state = CoachState(messages: history, loading: true);
    try {
      final config = await _ref.read(coachConfigProvider.future);
      final dash = await _ref.read(dashboardProvider.future);
      final age = await _ref.read(whoopAgeProvider.future);
      final profile = await _ref.read(profileProvider.future);
      final prompt = CoachContextBuilder.build(dashboard: dash, age: age, profile: profile);

      var sent = history.length > _maxHistory ? history.sublist(history.length - _maxHistory) : history;
      while (sent.isNotEmpty && !sent.first.fromUser) {
        sent = sent.sublist(1);
      }
      final reply = await _service.send(config: config, systemPrompt: prompt, history: sent);
      state = CoachState(messages: [...history, ChatMessage(fromUser: false, text: reply)]);
    } catch (e) {
      // Drop the unanswered message so roles keep alternating, and hand it back for retry.
      state = CoachState(
        messages: history.sublist(0, history.length - 1),
        error: _friendly(e),
        retryText: trimmed,
      );
    }
  }

  String _friendly(Object e) {
    if (e is TimeoutException) {
      return 'The model took too long to respond. Check your connection or try a smaller model.';
    }
    if (e is SocketException) {
      return 'Could not reach the endpoint. Check the URL, your network, and that the server is running.';
    }
    if (e is http.ClientException) {
      return 'Network error: ${e.message}';
    }
    return e.toString().replaceFirst('Exception: ', '');
  }

  void clear() => state = const CoachState();
}

final coachControllerProvider =
    StateNotifierProvider<CoachController, CoachState>((ref) => CoachController(ref));
