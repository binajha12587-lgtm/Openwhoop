#!/usr/bin/env bash
# Creates a release keystore once and prints the values to store as GitHub secrets.
# Keep release.jks safe: losing it means future builds cannot update installed copies.
set -euo pipefail
command -v keytool >/dev/null || { echo "keytool (JDK) not found"; exit 1; }
read -r -s -p "Choose a keystore password (min 6 chars): " PASS; echo
keytool -genkeypair -v -keystore release.jks -alias openwhoop -keyalg RSA -keysize 2048 \
  -validity 10000 -storepass "$PASS" -keypass "$PASS" -dname "CN=OpenWhoop"
echo
echo "Add these four repository secrets (Settings > Secrets and variables > Actions):"
echo "  KEYSTORE_PASSWORD = (the password you typed)"
echo "  KEY_PASSWORD      = (the same password)"
echo "  KEY_ALIAS         = openwhoop"
echo "  KEYSTORE_BASE64   = contents of release.jks.b64 (written next to the keystore)"
base64 < release.jks | tr -d '\n' > release.jks.b64
