import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/providers.dart';
import '../theme.dart';
import '../widgets/cards.dart';
import '../widgets/trend_chart.dart';

class RecoveryScreen extends ConsumerStatefulWidget {
  const RecoveryScreen({super.key});

  @override
  ConsumerState<RecoveryScreen> createState() => _RecoveryScreenState();
}

class _RecoveryScreenState extends ConsumerState<RecoveryScreen> {
  int _days = 30;

  @override
  Widget build(BuildContext context) {
    final cycles = ref.watch(trendCyclesProvider(_days));
    final sleeps = ref.watch(trendSleepsProvider(_days));
    final anchor = ref.watch(anchorProvider).valueOrNull ?? DateTime.now();
    final from = anchor.subtract(Duration(days: _days));

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 12),
          child: Text('RECOVERY & HEALTH', style: AppText.label),
        ),
        SegmentedButton<int>(
          showSelectedIcon: false,
          segments: const [
            ButtonSegment(value: 7, label: Text('7D')),
            ButtonSegment(value: 30, label: Text('30D')),
            ButtonSegment(value: 90, label: Text('3M')),
          ],
          selected: {_days},
          onSelectionChanged: (s) => setState(() => _days = s.first),
        ),
        const SizedBox(height: 16),
        if (cycles.isLoading || sleeps.isLoading)
          const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()))
        else if (cycles.hasError || sleeps.hasError)
          Text('${cycles.error ?? sleeps.error}')
        else ...[
          TrendChart(
            title: 'Recovery score',
            unit: '%',
            color: AppColors.recovery,
            from: from,
            days: _days,
            points: [
              for (final c in cycles.value!)
                if (c.recoveryScore != null) (t: c.start, v: c.recoveryScore!),
            ],
          ),
          TrendChart(
            title: 'Heart rate variability',
            unit: 'ms',
            color: AppColors.recovery,
            from: from,
            days: _days,
            points: [
              for (final c in cycles.value!)
                if (c.hrv != null) (t: c.start, v: c.hrv!),
            ],
          ),
          TrendChart(
            title: 'Resting heart rate',
            unit: 'bpm',
            color: AppColors.strain,
            from: from,
            days: _days,
            points: [
              for (final c in cycles.value!)
                if (c.restingHr != null) (t: c.start, v: c.restingHr!),
            ],
          ),
          TrendChart(
            title: 'Respiratory rate',
            unit: 'rpm',
            color: AppColors.sleep,
            decimals: 1,
            from: from,
            days: _days,
            points: [
              for (final s in sleeps.value!)
                if (s.respRate != null) (t: s.onset, v: s.respRate!),
            ],
          ),
          TrendChart(
            title: 'Sleep performance',
            unit: '%',
            color: AppColors.sleep,
            from: from,
            days: _days,
            points: [
              for (final s in sleeps.value!)
                if (s.performance != null) (t: s.onset, v: s.performance!),
            ],
          ),
          TrendChart(
            title: 'Time asleep',
            unit: 'h',
            color: AppColors.sleep,
            decimals: 1,
            from: from,
            days: _days,
            points: [
              for (final s in sleeps.value!)
                if (s.asleepMin != null) (t: s.onset, v: s.asleepMin! / 60),
            ],
          ),
          TrendChart(
            title: 'Blood oxygen',
            unit: '%',
            color: const Color(0xFF5AC8FA),
            decimals: 1,
            from: from,
            days: _days,
            points: [
              for (final c in cycles.value!)
                if (c.spo2 != null) (t: c.start, v: c.spo2!),
            ],
          ),
        ],
      ],
    );
  }
}
