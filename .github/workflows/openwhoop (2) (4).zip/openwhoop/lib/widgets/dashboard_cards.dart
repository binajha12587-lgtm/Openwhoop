import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../database/database.dart';
import '../models/dashboard.dart';
import '../services/whoop_age_calculator.dart';
import '../theme.dart';
import 'cards.dart';
import 'ring_gauge.dart';

/// Three compact rings across the top of the Today view.
class SummaryRings extends StatelessWidget {
  const SummaryRings({super.key, required this.cycle, required this.sleep});
  final Cycle cycle;
  final Sleep? sleep;

  @override
  Widget build(BuildContext context) {
    final rec = cycle.recoveryScore;
    final strain = cycle.dayStrain;
    final perf = sleep?.performance;
    Widget ring(String label, double progress, Color color, String value) => Expanded(
          child: Column(
            children: [
              RingGauge(
                size: 92,
                stroke: 8,
                progress: progress,
                color: color,
                center: Text(value, style: AppText.medium),
              ),
              const SizedBox(height: 8),
              Text(label, style: AppText.label),
            ],
          ),
        );
    return AppCard(
      child: Row(
        children: [
          ring('SLEEP', (perf ?? 0) / 100, AppColors.sleep, perf == null ? '--' : '${perf.round()}%'),
          ring('RECOVERY', (rec ?? 0) / 100, AppColors.recoveryBand(rec), rec == null ? '--' : '${rec.round()}%'),
          ring('STRAIN', (strain ?? 0) / 21, AppColors.strain, fmtNum(strain, dp: 1)),
        ],
      ),
    );
  }
}

class StrainCard extends StatelessWidget {
  const StrainCard({super.key, required this.cycle});
  final Cycle cycle;

  @override
  Widget build(BuildContext context) {
    final strain = cycle.dayStrain ?? 0;
    final target = strainTargetFor(cycle.recoveryScore);
    final remaining = target.hi - strain;
    final kcal = cycle.energyKcal;
    return AppCard(
      title: 'Day strain',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              RingGauge(
                size: 132,
                progress: strain / 21,
                color: AppColors.strain,
                center: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(strain.toStringAsFixed(1), style: AppText.big),
                    const Text('of 21', style: AppText.dim),
                  ],
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  children: [
                    KeyValueRow('Target', '${target.lo.toStringAsFixed(0)} – ${target.hi.toStringAsFixed(0)}'),
                    KeyValueRow('Energy', kcal == null ? '--' : '${kcal.round()} kcal'),
                    KeyValueRow('Energy (kJ)', kcal == null ? '--' : '${(kcal * 4.184).round()} kJ'),
                    KeyValueRow('Avg / Max HR', '${fmtNum(cycle.avgHr)} / ${fmtNum(cycle.maxHr)}'),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            remaining > 0.5
                ? 'Room for about ${remaining.toStringAsFixed(1)} more strain today.'
                : 'You are at or above your recommended strain. Prioritise recovery.',
            style: AppText.dim,
          ),
        ],
      ),
    );
  }
}

class RecoveryCard extends StatelessWidget {
  const RecoveryCard({super.key, required this.cycle});
  final Cycle cycle;

  @override
  Widget build(BuildContext context) {
    final pct = cycle.recoveryScore;
    final color = AppColors.recoveryBand(pct);
    final verdict = pct == null ? 'No score' : pct >= 67 ? 'Primed' : pct >= 34 ? 'Maintain' : 'Rest';
    return AppCard(
      title: 'Recovery',
      child: Column(
        children: [
          Row(
            children: [
              RingGauge(
                size: 132,
                progress: (pct ?? 0) / 100,
                color: color,
                center: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(pct == null ? '--' : '${pct.round()}%', style: AppText.big.copyWith(color: color)),
                    Text(verdict, style: AppText.dim),
                  ],
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  children: [
                    Row(children: [
                      Expanded(child: StatTile(label: 'RHR', value: fmtNum(cycle.restingHr), unit: 'bpm')),
                      Expanded(child: StatTile(label: 'HRV', value: fmtNum(cycle.hrv), unit: 'ms')),
                    ]),
                    const SizedBox(height: 16),
                    Row(children: [
                      Expanded(child: StatTile(label: 'Skin temp', value: fmtNum(cycle.skinTemp, dp: 1), unit: '°C')),
                      Expanded(child: StatTile(label: 'SpO₂', value: fmtNum(cycle.spo2, dp: 1), unit: '%')),
                    ]),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class SleepCard extends StatelessWidget {
  const SleepCard({super.key, required this.sleep});
  final Sleep sleep;

  static const lightColor = Color(0xFFD8B4FE);
  static const deepColor = Color(0xFF7E22CE);
  static const awakeColor = Color(0xFF48484A);

  @override
  Widget build(BuildContext context) {
    final perf = sleep.performance;
    return AppCard(
      title: 'Sleep',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(fmtMinutes(sleep.asleepMin), style: AppText.big),
              const Spacer(),
              Text(perf == null ? '--' : '${perf.round()}% performance',
                  style: AppText.body.copyWith(color: AppColors.sleep, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: math.max(0.0, math.min(1.0, (perf ?? 0) / 100)),
              minHeight: 10,
              color: AppColors.sleep,
              backgroundColor: AppColors.track,
            ),
          ),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: StatTile(label: 'Efficiency', value: fmtNum(sleep.efficiency), unit: '%')),
            Expanded(child: StatTile(label: 'Sleep debt', value: fmtMinutes(sleep.debtMin))),
            Expanded(child: StatTile(label: 'Need', value: fmtMinutes(sleep.needMin))),
          ]),
          const SizedBox(height: 18),
          _StageBar(
            awake: sleep.awakeMin ?? 0,
            light: sleep.lightMin ?? 0,
            deep: sleep.deepMin ?? 0,
            rem: sleep.remMin ?? 0,
          ),
          const SizedBox(height: 12),
          _legend('Awake', sleep.awakeMin, awakeColor),
          _legend('Light', sleep.lightMin, lightColor),
          _legend('Slow wave (deep)', sleep.deepMin, deepColor),
          _legend('REM', sleep.remMin, AppColors.sleep),
        ],
      ),
    );
  }

  Widget _legend(String name, double? min, Color color) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 10),
          Expanded(child: Text(name, style: AppText.dim)),
          Text(fmtMinutes(min), style: AppText.body),
        ]),
      );
}

class _StageBar extends StatelessWidget {
  const _StageBar({required this.awake, required this.light, required this.deep, required this.rem});
  final double awake, light, deep, rem;

  @override
  Widget build(BuildContext context) {
    final parts = <(double, Color)>[
      (awake, SleepCard.awakeColor),
      (light, SleepCard.lightColor),
      (deep, SleepCard.deepColor),
      (rem, AppColors.sleep),
    ].where((p) => p.$1 > 0).toList();
    if (parts.isEmpty) return const SizedBox.shrink();
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: SizedBox(
        height: 14,
        child: Row(
          children: [
            for (final p in parts)
              Expanded(flex: math.max(1, (p.$1 * 10).round()), child: ColoredBox(color: p.$2)),
          ],
        ),
      ),
    );
  }
}

/// Day strain vs. capacity, plus HRV vs. baseline as an autonomic proxy.
/// Derived from daily metrics: continuous stress tracking needs a live HR stream.
class StressCard extends StatelessWidget {
  const StressCard({super.key, required this.cycle, required this.trends});
  final Cycle cycle;
  final TrendSummary trends;

  @override
  Widget build(BuildContext context) {
    final target = strainTargetFor(cycle.recoveryScore);
    final load = target.hi <= 0 ? 0.0 : (cycle.dayStrain ?? 0) / target.hi;
    final baseline = trends.hrv;
    final hrv = cycle.hrv;
    final auto = (baseline == null || hrv == null || baseline == 0)
        ? 0.5
        : math.max(0.0, math.min(1.0, 0.5 + (1 - hrv / baseline)));
    final stress = math.max(0.0, math.min(1.0, 0.6 * math.min(load, 1.2) / 1.2 + 0.4 * auto));
    final label = stress < 0.35 ? 'Low' : stress < 0.65 ? 'Moderate' : 'High';
    final color = stress < 0.35 ? AppColors.recovery : stress < 0.65 ? AppColors.yellow : AppColors.red;
    return AppCard(
      title: 'Stress monitor',
      trailing: Text(label.toUpperCase(), style: AppText.label.copyWith(color: color)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _bar('Day strain vs target', math.min(load, 1.0), AppColors.strain),
          const SizedBox(height: 14),
          _bar('Autonomic load (HRV vs baseline)', auto, AppColors.sleep),
          const SizedBox(height: 12),
          const Text(
            'Estimated from today\'s strain, HRV and your 3-month baseline.',
            style: AppText.tiny,
          ),
        ],
      ),
    );
  }

  Widget _bar(String label, double value, Color color) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: AppText.dim),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: value,
              minHeight: 8,
              color: color,
              backgroundColor: AppColors.track,
            ),
          ),
        ],
      );
}

class AgeCard extends StatelessWidget {
  const AgeCard({super.key, required this.result, required this.onSetup});
  final WhoopAgeResult? result;
  final VoidCallback onSetup;

  @override
  Widget build(BuildContext context) {
    final r = result;
    if (r == null) {
      return AppCard(
        title: 'Fitness age',
        child: Row(children: [
          const Expanded(child: Text('Add your birth year to estimate your biological fitness age.', style: AppText.dim)),
          TextButton(onPressed: onSetup, child: const Text('Set up')),
        ]),
      );
    }
    if (!r.sufficient) {
      return AppCard(
        title: 'Fitness age',
        child: Text(
          'Needs at least ${WhoopAgeCalculator.minDays} days of data (found ${r.sampleDays}).',
          style: AppText.dim,
        ),
      );
    }
    final delta = r.delta;
    final color = delta <= 0 ? AppColors.recovery : AppColors.strain;
    return AppCard(
      title: 'Fitness age · 3-month window',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(r.whoopAge.toStringAsFixed(1), style: AppText.big.copyWith(color: color)),
              const SizedBox(width: 10),
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  '${delta.abs().toStringAsFixed(1)} yrs ${delta <= 0 ? 'younger' : 'older'} than your ${r.chronologicalAge.floor()}',
                  style: AppText.dim,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          for (final f in r.factors) _factor(f),
        ],
      ),
    );
  }

  Widget _factor(AgeFactor f) {
    final c = f.younger ? AppColors.recovery : f.older ? AppColors.strain : AppColors.textDim;
    final sign = f.deltaYears > 0 ? '+' : '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 56,
            child: Text('$sign${f.deltaYears.toStringAsFixed(1)}y',
                style: AppText.medium.copyWith(color: c, fontSize: 16)),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(f.name, style: AppText.body.copyWith(fontWeight: FontWeight.w600)),
                Text(f.detail, style: AppText.dim),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Last 7 days compared with the 3-month baseline.
class WeeklyCard extends StatelessWidget {
  const WeeklyCard({super.key, required this.week, required this.baseline});
  final TrendSummary week;
  final TrendSummary baseline;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      title: 'Last 7 days vs 3-month baseline',
      child: Column(
        children: [
          _row('Recovery', week.recovery, baseline.recovery, '%', 0, higherIsBetter: true),
          _row('HRV', week.hrv, baseline.hrv, ' ms', 0, higherIsBetter: true),
          _row('Resting HR', week.rhr, baseline.rhr, ' bpm', 0, higherIsBetter: false),
          _row('Sleep performance', week.sleepPerformance, baseline.sleepPerformance, '%', 0, higherIsBetter: true),
          _row('Day strain', week.strain, baseline.strain, '', 1),
        ],
      ),
    );
  }

  Widget _row(String label, double? now, double? base, String unit, int dp, {bool? higherIsBetter}) {
    final diff = (now == null || base == null) ? null : now - base;
    var color = AppColors.textDim;
    var icon = Icons.remove;
    if (diff != null && diff.abs() >= (dp == 0 ? 0.5 : 0.05)) {
      icon = diff > 0 ? Icons.arrow_upward : Icons.arrow_downward;
      if (higherIsBetter != null) {
        color = (diff > 0) == higherIsBetter ? AppColors.recovery : AppColors.strain;
      }
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(child: Text(label, style: AppText.dim)),
          Text('${fmtNum(now, dp: dp)}$unit', style: AppText.body.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(width: 10),
          Icon(icon, size: 16, color: color),
          SizedBox(
            width: 56,
            child: Text(
              diff == null ? '--' : '${diff >= 0 ? '+' : ''}${diff.toStringAsFixed(dp)}',
              textAlign: TextAlign.right,
              style: AppText.dim.copyWith(color: color),
            ),
          ),
        ],
      ),
    );
  }
}
